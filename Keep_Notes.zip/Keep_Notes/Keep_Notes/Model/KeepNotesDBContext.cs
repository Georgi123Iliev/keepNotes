﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Keep_Notes.Model;

namespace Keep_Notes
{
    public partial class KeepNotesDBContext : DbContext
    {
        public KeepNotesDBContext()
        {
        }

        public KeepNotesDBContext(DbContextOptions<KeepNotesDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AgeGroups> AgeGroups { get; set; }
        public virtual DbSet<Cities> Cities { get; set; }
        public virtual DbSet<Efmigrationshistory> Efmigrationshistory { get; set; }
        public virtual DbSet<Notes> Notes { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySQL("server = 127.0.0.1; user = test; database = keep_notes; port = 3306; pwd = 1234");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AgeGroups>(entity =>
            {
                entity.ToTable("age_groups");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Age)
                    .HasColumnName("age")
                    .HasColumnType("enum('7-12','13-18','19-30','31-50','51-70','70+')");
            });

            modelBuilder.Entity<Cities>(entity =>
            {
                entity.ToTable("cities");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(30);
            });

            modelBuilder.Entity<Efmigrationshistory>(entity =>
            {
                entity.HasKey(e => e.MigrationId)
                    .HasName("PRIMARY");

                entity.ToTable("__efmigrationshistory");

                entity.Property(e => e.MigrationId).HasMaxLength(150);

                entity.Property(e => e.ProductVersion)
                    .IsRequired()
                    .HasMaxLength(32);
            });

            modelBuilder.Entity<Notes>(entity =>
            {
                
               
                
                entity.ToTable("notes");
                
              

                entity.Property(e => e.Title)
                    .HasColumnName("title")
                    .HasMaxLength(33);

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.Property(e => e.Color)
                    .HasColumnName("color")
                    .HasMaxLength(10)
                    .HasDefaultValueSql("'#FFFFFF'");

                entity.Property(e => e.Keywords)
                    .HasColumnName("keywords")
                    .HasColumnType("enum('Cooking','Studying','Articles','Books','Other')")
                    .HasDefaultValueSql("'Other'");

                entity.Property(e => e.Note)
                    .IsRequired()
                    .HasColumnName("note");

                entity.Property(e => e.Password)
                    .HasColumnName("password")
                    .HasMaxLength(1000);

                entity.Property(e => e.Private)
                    .HasColumnName("private")
                    .HasDefaultValueSql("'0'");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Notes)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_user_note");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.ToTable("users");

                entity.HasIndex(e => e.AgeGroupId)
                    .HasName("FK_age_group_user");

                entity.HasIndex(e => e.CityId)
                    .HasName("FK_city_user");

                entity.HasIndex(e => e.Username)
                    .HasName("username");
               

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AgeGroupId).HasColumnName("age_group_id");

                entity.Property(e => e.CityId).HasColumnName("city_id");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password")
                    .HasMaxLength(1000);

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasMaxLength(50);

                entity.HasOne(d => d.AgeGroup)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.AgeGroupId)
                    .HasConstraintName("FK_age_group_user");

                entity.HasOne(d => d.City)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.CityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_city_user");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}