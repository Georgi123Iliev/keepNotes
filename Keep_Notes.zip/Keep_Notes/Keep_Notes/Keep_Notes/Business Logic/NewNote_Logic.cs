﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Keep_Notes.Model;
using System.Timers;

namespace Keep_Notes.Business_Logic
{
    class NewNote_Logic : INoteLogic
    {
        static KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();
     
        public NewNote_Logic()
        {

        }
        public List<string> StartUp(int NoteId)
        {
            return new List<string> { "" };//this method should never be called in this class
        }
        public string Save(int user_id,string title, string note, bool priv, string category, string color, string password = "",int NoteId = -1)
        {

            //
            if (keepNotesDBContext.Notes.Where(n => n.Title == title && n.UserId == user_id).ToList().Count != 0)
                return "Invalid title";

            else
            {
                var CurrentNote = new Notes();
                if(keepNotesDBContext.Notes.ToList().Count == 0)
                {
                    CurrentNote.Id = 1;
                }
                else CurrentNote.Id = keepNotesDBContext.Notes.Max(n=>n.Id)+1;
                CurrentNote.Title = title;
                CurrentNote.creation_date = DateTime.Now;
                CurrentNote.latest_change = DateTime.Now;
                CurrentNote.Note = note;
                CurrentNote.Private = priv;
                if (priv)
                    CurrentNote.Password = password;
                CurrentNote.Keywords = category;
                CurrentNote.Color = color;
                CurrentNote.UserId = user_id;


                keepNotesDBContext.Notes.Add(CurrentNote);
                keepNotesDBContext.SaveChanges();
                return "Note Saved";
            }


        }

        public string NotSavedMessage
        {
            get { return "Exit whithout saving? The note will not be saved if you proceed"; }
        }
    }
}
