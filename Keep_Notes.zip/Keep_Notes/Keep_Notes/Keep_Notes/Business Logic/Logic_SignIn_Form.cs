﻿using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;


namespace Keep_Notes.Business_Logic
{
    public class Logic_SignIn_Form
    {
        public KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();

        public Tuple<string, Users> OnSignInButtonClick(string email_TextBox, string password_TextBox)
        {
            string passwordForChecking = "";
            using (var sha256 = SHA256.Create())
            {
                // Send a sample text to hash.  
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password_TextBox));
                // Get the hashed string.  
                var hash = BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
                passwordForChecking = hash;
            }
            //Checking if the required user exists in the database
            var userExist = keepNotesDBContext.Users
                .Where(kN => kN.Username.Equals(email_TextBox))
                .Where(kN => kN.Password.Equals(passwordForChecking.ToString()))
                .ToList()
                .FirstOrDefault();
            //Checking if the required user exists in the database
            if (userExist == null)
            {
                return new Tuple<string, Users>("Wrong password or email", null);
            }
            else
            {
                return new Tuple<string, Users>("READY", userExist);
            }
        }

        public void register_LinkLabel_LinkClicked(signIn_Form signIn_Form)
        {
            // The transition between the Sign_In_Form and the Register_Form
            var registerForm = new Register(signIn_Form);
            registerForm.Show();
            signIn_Form.Hide();
        }
    }
}
