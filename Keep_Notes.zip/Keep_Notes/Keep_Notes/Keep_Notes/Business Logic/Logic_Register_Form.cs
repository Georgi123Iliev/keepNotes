﻿using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Keep_Notes.Business_Logic
{
    public class Logic_Register_Form
    {
        //Theses variables will be used in the Ready form
        public static string SetValueForText1 = "";
        public static string SetValueForText2 = "";
        public static string SetValueForText3 = "";
        public static string SetValueForText4 = "";
        public KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();

        public signIn_Form signIn_Form;

        public Logic_Register_Form(signIn_Form signIn_Form)
        {
            this.signIn_Form = signIn_Form;
        }

        public void On_Ready_Button_Click(string email_TextBox, string password_TextBox, string passwordConfirmation_TextBox, string city_TextBox, string age_TextBox, Label warning_Label, Label warning_age_Label, Register register)
        {
            Users newUser = new Users();
            //Checking the email
            Regex rgx = new Regex(@"^[a-zA-Z0-9_+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-]+$");
            MatchCollection matches = rgx.Matches(email_TextBox);
            if (matches != null && matches.Count == 1)
            {
                newUser.Username = email_TextBox;

                //Checking the passsword
                if (password_TextBox == passwordConfirmation_TextBox && password_TextBox.Length >= 5)
                {
                    newUser.Password = password_TextBox;

                    bool cityFlag = false;
                    //Finding if there is such city
                    Cities city = (Cities)keepNotesDBContext.Cities.Where(c => c.Name == city_TextBox).FirstOrDefault();
                    //If there is such city
                    if (city != null)
                    {
                        cityFlag = true;
                        newUser.CityId = city.Id;
                    }
                    //If there is not such city
                    else if (city_TextBox.Length > 3)
                    {
                        cityFlag = true;
                        city = new Cities();
                        city.Name = city_TextBox;

                        if (keepNotesDBContext.Cities.Count() != 0)
                            city.Id = keepNotesDBContext.Cities.OrderByDescending(p => p.Id).FirstOrDefault().Id + 1;
                        else
                            city.Id = 1;

                        keepNotesDBContext.Cities.Add(city);
                        keepNotesDBContext.SaveChanges();
                        newUser.CityId = city.Id;
                    }
                    else
                    {
                        warning_Label.Text = "Enter a valid age";
                    }
                    if (cityFlag)
                    {
                        //Defining the age group of the new user
                        //7-12
                        //13 - 18
                        //19 - 30
                        //31 - 50
                        //51 - 70
                        //70 +
                        if (age_TextBox.Length > 0)
                        {
                            bool flag = true;
                            if (int.Parse(age_TextBox) >= 71) newUser.AgeGroupId = 6;
                            else if (int.Parse(age_TextBox) >= 51 && int.Parse(age_TextBox) <= 70) newUser.AgeGroupId = 5;
                            else if (int.Parse(age_TextBox) >= 31 && int.Parse(age_TextBox) <= 50) newUser.AgeGroupId = 4;
                            else if (int.Parse(age_TextBox) >= 19 && int.Parse(age_TextBox) <= 30) newUser.AgeGroupId = 3;
                            else if (int.Parse(age_TextBox) >= 13 && int.Parse(age_TextBox) <= 18) newUser.AgeGroupId = 2;
                            else if (int.Parse(age_TextBox) >= 7 && int.Parse(age_TextBox) <= 12) newUser.AgeGroupId = 1;
                            else
                            {
                                flag = false;
                                warning_age_Label.Text = "You cannot make a registration if you are not at least 7 year old";
                            }

                            if (flag)
                            {
                                //Adding the new User
                                if (keepNotesDBContext.Users.Count() != 0)
                                    newUser.Id = keepNotesDBContext.Users.OrderByDescending(p => p.Id).FirstOrDefault().Id + 1;
                                else
                                    newUser.Id = 1;
                                SetValueForText1 = newUser.Username;
                                SetValueForText2 = newUser.Password;
                                SetValueForText3 = city_TextBox;
                                SetValueForText4 = age_TextBox;
                                var ReadyForm = new Ready(newUser, register, this);
                                register.Hide();
                                ReadyForm.Show();
                            }
                        }
                    }
                    else warning_Label.Text = "Enter a valid city name";

                }
                //If the password is not correct
                else
                {
                    warning_Label.Text = "The password is not correct.";
                }

            }
            //If the email is not correct
            else
            {
                warning_Label.Text = "Wrong email. Enter a valid one!";
            }
        }

        public void On_Close_Button_Click(Register register)
        {
            register.Close();
            signIn_Form.Show();
        }
    }
}
