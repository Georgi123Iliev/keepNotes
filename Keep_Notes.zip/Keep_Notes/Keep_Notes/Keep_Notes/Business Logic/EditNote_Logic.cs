﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Keep_Notes.Model;
using System.Timers;
namespace Keep_Notes.Business_Logic
{
    class EditNote_Logic : INoteLogic
    {
        static KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();
        bool saved = true;
        
       
        // Composing the asked note
        public List<string> StartUp(int NoteId)
        {
            List<string> result = new List<string>(6);

            result.Add(keepNotesDBContext.Notes.Where(n => n.Id == NoteId).FirstOrDefault().Title);
            result.Add(keepNotesDBContext.Notes.Where(n => n.Id == NoteId).FirstOrDefault().Note);
            result.Add(keepNotesDBContext.Notes.Where(n => n.Id == NoteId).FirstOrDefault().Private.ToString());

            if (result[2] == "True")
                result.Add(keepNotesDBContext.Notes.Where(n => n.Id == NoteId).FirstOrDefault().Password);
            else
                result.Add("");

            result.Add(keepNotesDBContext.Notes.Where(n => n.Id == NoteId).FirstOrDefault().Keywords);
            result.Add(keepNotesDBContext.Notes.Where(n => n.Id == NoteId).FirstOrDefault().Color);

            return result;

        }


        //Saving the note and checking if there is any mistakes
        public string Save(int user_id,string title, string note, bool priv, string category, string color, string password = "", int NoteId = -1)
        {
            if (keepNotesDBContext.Notes.Where(n => n.Title == title && n.UserId == user_id && n.Id != NoteId).FirstOrDefault() != null)
                return "Invalid title";

            Notes currentNote = keepNotesDBContext.Notes.Where(n => n.Id == NoteId).FirstOrDefault();
            currentNote.Title = title;
            currentNote.Note = note;
            if (priv)
                currentNote.Password = password;
            else
                currentNote.Password = null;
            currentNote.Private = priv;
            currentNote.Keywords = category;
            currentNote.Color = color;
           
            keepNotesDBContext.SaveChanges();
            return "Note Saved";
        }

        //Message if the saving of the note is asked 
        public string NotSavedMessage
        {
            get { return "Exit whithout saving? The changes to the note will not be saved if you proceed"; }
        }
    }
}
