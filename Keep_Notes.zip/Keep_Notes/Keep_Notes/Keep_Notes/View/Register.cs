﻿using Keep_Notes.Business_Logic;
using Keep_Notes.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Keep_Notes.View
{
    public partial class Register : Form
    {
        // Declared the business logic for the Register_Form
        static Logic_Register_Form logic_Register_Form;
        public Register(signIn_Form sign_in)
        {
            InitializeComponent();
            logic_Register_Form = new Logic_Register_Form(sign_in);
        }

        private void ready_Button_Click(object sender, EventArgs e)
        {
            logic_Register_Form.On_Ready_Button_Click(email_TextBox.Text, password_TextBox.Text, passwordConfirmation_TextBox.Text, city_TextBox.Text, age_TextBox.Text, warning_Label, warning_age_Label, this);
        }

        public void close_Button_Click(object sender, EventArgs e)
        {
            logic_Register_Form.On_Close_Button_Click(this);
        }
    }
}
