﻿using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Keep_Notes.Business_Logic
{
    public class Logic_Ready_Form
    {
        public static KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();
        public Register register;
        public Logic_Register_Form logic_Register_Form;
        public static bool IsReady = true;
        public Users user;

        public Logic_Ready_Form(Users users, Register register, Logic_Register_Form logic_Register_Form)
        {
            this.user = users;
            this.register = register;
            this.logic_Register_Form = logic_Register_Form;
        }

        public void On_Ready_Load(Label emailOutput_Label, Label passwordOutput_Label, Label cityOutput_Label, Label ageOutput_Label)
        {
            //Setting the public variables from the register form here
            emailOutput_Label.Text = Logic_Register_Form.SetValueForText1;
            passwordOutput_Label.Text = Logic_Register_Form.SetValueForText2;
            cityOutput_Label.Text = Logic_Register_Form.SetValueForText3;
            ageOutput_Label.Text = Logic_Register_Form.SetValueForText4;
        }

        public void On_Ready_Button_Click(Ready ready)
        {
            //If the costumer is ready with the registration this form and the registration form should be closed
            keepNotesDBContext.Users.Add(this.user);
            keepNotesDBContext.SaveChanges();
            ready.Close();
            logic_Register_Form.signIn_Form.Show();
            register.Close();
        }

        public void On_Edit_Button_Click(Ready ready)
        {
            //If the costumer is not ready with the registration this form should be closed and the registration form shold stay active
            ready.Close();
            register.Show();
        }
    }
}
