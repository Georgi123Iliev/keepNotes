﻿using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace Keep_Notes.Business_Logic
{
    public class Logic_Ready_Form
    {
        public static KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();
        public static bool IsReady = true;
        public Users user;
        public string[] stringsForLabels;

        public Logic_Ready_Form(string[] stringsForLabels)
        {
            this.stringsForLabels = stringsForLabels;
        }

        public void On_Ready_Button_Click(Ready ready)
        {
            user = new Users();
            user.Id = int.Parse(stringsForLabels[2]);
            user.Username = stringsForLabels[3];
            using (var sha256 = SHA256.Create())
            {
                // Send a sample text to hash.  
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(stringsForLabels[4]));
                // Get the hashed string.  
                var hash = BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
                user.Password = hash;
            }
            //Finding if there is such city
            Cities city = (Cities)keepNotesDBContext.Cities.Where(c => c.Name == stringsForLabels[5]).FirstOrDefault();
            //If there is such city
            if (city != null)
            {
                user.CityId = city.Id;
            }
            else
            {
                city = new Cities();
                city.Name = stringsForLabels[5];

                if (keepNotesDBContext.Cities.Count() != 0)
                    city.Id = keepNotesDBContext.Cities.OrderByDescending(p => p.Id).FirstOrDefault().Id + 1;
                else
                    city.Id = 1;

                keepNotesDBContext.Cities.Add(city);
                keepNotesDBContext.SaveChanges();
                user.City = city;
            }
            if (int.Parse(stringsForLabels[6]) >= 71) user.AgeGroupId = 6;
            else if (int.Parse(stringsForLabels[6]) >= 51 && int.Parse(stringsForLabels[6]) <= 70) user.AgeGroupId = 5;
            else if (int.Parse(stringsForLabels[6]) >= 31 && int.Parse(stringsForLabels[6]) <= 50) user.AgeGroupId = 4;
            else if (int.Parse(stringsForLabels[6]) >= 19 && int.Parse(stringsForLabels[6]) <= 30) user.AgeGroupId = 3;
            else if (int.Parse(stringsForLabels[6]) >= 13 && int.Parse(stringsForLabels[6]) <= 18) user.AgeGroupId = 2;
            else if (int.Parse(stringsForLabels[6]) >= 7 && int.Parse(stringsForLabels[6]) <= 12) user.AgeGroupId = 1;
            
            //If the costumer is ready with the registration this form and the registration form should be closed
            keepNotesDBContext.Users.Add(this.user);
            keepNotesDBContext.SaveChanges();
        }
    }
}
