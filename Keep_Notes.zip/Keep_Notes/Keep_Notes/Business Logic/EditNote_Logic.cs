﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Keep_Notes.Business_Logic
{
    class EditNote_Logic : INoteLogic
    {
        bool saved=true;
        
        public bool Saved
        {
            get { return saved; }
            set { saved = value; }
        }
        
    
            
       
        public string Save(int user_id,string title, string note, bool priv, string category, string color, string password = "")
        {
            return "";
        }
        public string NotSavedMessage
        {
            get { return "Exit whithout saving? The changes to the note will not be saved if you proceed"; }
        }
    }
}
