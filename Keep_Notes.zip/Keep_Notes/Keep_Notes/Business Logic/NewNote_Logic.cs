﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Keep_Notes.Business_Logic
{
    class NewNote_Logic : INoteLogic
    {
        static KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();
        bool saved = false;
        public bool Saved
        {
            get { return saved; }
            set { saved = value; }
        }
        public NewNote_Logic()
        {

        }
        public string Save(int user_id,string title, string note, bool priv, string category, string color, string password = "")
        {
            
            //
            if (keepNotesDBContext.Notes.Where(n => n.Title == title&&n.UserId==user_id).ToList().Count != 0)
                return "Invalid title";
            
            else
                //todo
                return "Note Saved";


        }
        public string NotSavedMessage
        {
            get { return "Exit whithout saving? The note will not be saved if you proceed"; }
        }
    }
}
