﻿using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace Keep_Notes.Business_Logic
{
   public class Logic_NotesMenu_Form
    {
        public static KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();
        public List<string> UpdateNoteList(int UserId,string keyword="Any")
        {
            
           
            List<Notes> listOfNotes;
            if(keyword=="Any")
            listOfNotes = keepNotesDBContext.Notes.Where(n => n.UserId == UserId).OrderByDescending(n=>n.latest_change).ToList();
            else
                listOfNotes = keepNotesDBContext.Notes.Where(n => n.UserId == UserId && n.Keywords==keyword).OrderByDescending(n => n.latest_change).ToList();


            List<string> titles = new List<string>(listOfNotes.Count);
            foreach (var i in listOfNotes)
                titles.Add(i.Title);
           
            return titles;
        }
        public string DisplayNotePreview(string title)
        {
            
                if (keepNotesDBContext.Notes.Where(n => n.Title == title).FirstOrDefault().Private)
                    return "***********";
                var note = keepNotesDBContext.Notes.Where(n => n.Title == title).FirstOrDefault();
                StringBuilder prevText = new StringBuilder();
                foreach (var i in note.Note.Take(20))
                {
                    prevText.Append(i);

                }
                return prevText + (note.Note.Length > 20 ? "..." : "");
            
            
        }
        public void DeleteNode(string title)
        {
            var ToRemove = keepNotesDBContext.Notes.Where(n => n.Title == title).FirstOrDefault();
            keepNotesDBContext.Notes.Remove(ToRemove);

            keepNotesDBContext.SaveChanges();
           
            
        }
    }
}
