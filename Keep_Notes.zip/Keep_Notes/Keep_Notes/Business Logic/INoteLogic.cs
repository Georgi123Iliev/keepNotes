﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Keep_Notes.Business_Logic
{
  public  interface INoteLogic
    {
        public List<string> StartUp(int NoteId);
       
        public string Save(int user_id, string title, string note, bool priv, string category, string color, string password = "", int NoteId = -1);

        public string NotSavedMessage { get; }   
    }
}
