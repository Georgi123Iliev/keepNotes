﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Keep_Notes.Business_Logic
{
  public  interface INoteLogic
    {
        public bool Saved { get; set; }
        public string Save(int user_id,string title,string note,bool priv,string category,string color,string password = "");
        public string NotSavedMessage { get; }
        
       
    }
}
