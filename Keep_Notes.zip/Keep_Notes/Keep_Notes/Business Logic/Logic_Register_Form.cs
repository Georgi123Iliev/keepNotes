﻿using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Keep_Notes.Business_Logic
{
    public class Logic_Register_Form
    {
        //Theses variables will be used in the Ready form
        public KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();
        
        public string[] On_Ready_Button_Click(string email_TextBox, string password_TextBox, string passwordConfirmation_TextBox, string city_TextBox, string age_TextBox)
        {
            Users newUser = new Users();
            //Checking the email
            Regex rgx = new Regex(@"^[a-zA-Z0-9_+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-]+$");
            MatchCollection matches = rgx.Matches(email_TextBox);
            if (matches != null && matches.Count == 1)
            {
                Users userForChecking = (Users)keepNotesDBContext.Users.Where(c => c.Username.Equals(email_TextBox,StringComparison.Ordinal)).FirstOrDefault();
                if (userForChecking == null)
                {
                    newUser.Username = email_TextBox;

                    //Checking the passsword
                    if (password_TextBox == passwordConfirmation_TextBox && password_TextBox.Length >= 5)
                    {
                        bool cityFlag = false;
                        //Finding if there is such city
                        Cities city = (Cities)keepNotesDBContext.Cities.Where(c => c.Name.Equals(city_TextBox, StringComparison.Ordinal)).FirstOrDefault();
                        //If there is such city
                        if (city != null)
                        {
                            cityFlag = true;
                            newUser.CityId = city.Id;
                        }
                        //If there is not such city
                        else if (city_TextBox.Length > 3)
                        {
                            
                            cityFlag = true;
                        }
                        else
                        {
                            return new string[] {"Enter a valid city name", ""};
                        }
                        if (cityFlag)
                        {
                            //Defining the age group of the new user
                            //7-12
                            //13 - 18
                            //19 - 30
                            //31 - 50
                            //51 - 70
                            //70 +
                            if (age_TextBox.Length > 0)
                            {
                                bool flag = true;
                                if (int.Parse(age_TextBox) >= 71) newUser.AgeGroupId = 6;
                                else if (int.Parse(age_TextBox) >= 51 && int.Parse(age_TextBox) <= 70) newUser.AgeGroupId = 5;
                                else if (int.Parse(age_TextBox) >= 31 && int.Parse(age_TextBox) <= 50) newUser.AgeGroupId = 4;
                                else if (int.Parse(age_TextBox) >= 19 && int.Parse(age_TextBox) <= 30) newUser.AgeGroupId = 3;
                                else if (int.Parse(age_TextBox) >= 13 && int.Parse(age_TextBox) <= 18) newUser.AgeGroupId = 2;
                                else if (int.Parse(age_TextBox) >= 7 && int.Parse(age_TextBox) <= 12) newUser.AgeGroupId = 1;
                                else
                                {
                                    flag = false;
                                    return new string[] { "", "You cannot make a registration if you are not at least 7 year old!" };
                                }

                                if (flag)
                                {
                                    //Adding the new User
                                    if (keepNotesDBContext.Users.Count() != 0)
                                        newUser.Id = keepNotesDBContext.Users.OrderByDescending(p => p.Id).FirstOrDefault().Id + 1;
                                    else
                                        newUser.Id = 1;
                                    return new string[] { "READY", "", newUser.Id.ToString(), newUser.Username, password_TextBox, city_TextBox, age_TextBox };
                                }
                            }
                            else
                            {
                                return new string[] { "Enter an age!", "" };
                            }

                        }
                       
                    }
                    //If the password is not correct
                    else if (password_TextBox.Length < 5) return new string[] { "", "The password must be at least 5 symbols!" };
                    else return new string[] { "", "The second password must be identical to the first one!" };
                }

                else
                {
                    return new string[] { "There is already a user with this email!", "" };
                }

            }
            //If the email is not correct
            else
            {
                return new string[] { "Wrong email. Enter a valid one!", "" };
            }

            return new string[] { "//THIS SHOULDN'T BE VALID", "" };
        }
    }
}
