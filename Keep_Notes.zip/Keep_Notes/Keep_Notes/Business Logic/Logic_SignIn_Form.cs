﻿using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Keep_Notes.Business_Logic
{
    public class Logic_SignIn_Form
    {
        public Users theUser;

        public KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();
        NotesMenu notesMenu;

        
        

        public void OnSignInButtonClick(TextBox email_TextBox, TextBox password_TextBox, Label warning_Label, signIn_Form signIn_Form)
        {
           
            //Checking if the required user exists in the database
            var userExist = keepNotesDBContext.Users
                .Where(kN => kN.Username.Equals(email_TextBox.Text))
                .Where(kN => kN.Password.Equals(password_TextBox.Text))
                .ToList()
                .FirstOrDefault();
            //Checking if the required user exists in the database
            if (userExist == null)
            {
                warning_Label.Text = "Wrong password or email";
            }
            else
            {
                // theUser should be used for the notes
                theUser = (Users)userExist;

                notesMenu = new NotesMenu(theUser, signIn_Form);
                notesMenu.Show();
                signIn_Form.Hide();//closing this window would end the application so we hide it
                                   //reset text fields
                email_TextBox.Text = "";
                password_TextBox.Text = "";
                warning_Label.Text = "";

            }
        }

        public void register_LinkLabel_LinkClicked(signIn_Form signIn_Form)
        {
            // The transition between the Sign_In_Form and the Register_Form
            var registerForm = new Register(signIn_Form);
            registerForm.Show();
            signIn_Form.Hide();
        }
    }
}
