﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Keep_Notes.Migrations
{
    public partial class configuredb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_user_note",
                table: "notes");

            migrationBuilder.DropPrimaryKey(
                name: "PRIMARY",
                table: "notes");

            migrationBuilder.AlterColumn<string>(
                name: "username",
                table: "users",
                maxLength: 50,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(25)",
                oldMaxLength: 25);

            migrationBuilder.AddPrimaryKey(
                name: "PRIMARY",
                table: "notes",
                columns: new[] { "title", "user_id" });

            migrationBuilder.AddForeignKey(
                name: "FK_user_note",
                table: "notes",
                column: "user_id",
                principalTable: "users",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_user_note",
                table: "notes");

            migrationBuilder.DropPrimaryKey(
                name: "PRIMARY",
                table: "notes");

            migrationBuilder.AlterColumn<string>(
                name: "username",
                table: "users",
                type: "varchar(25)",
                maxLength: 25,
                nullable: false,
                oldClrType: typeof(string),
                oldMaxLength: 50,
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PRIMARY",
                table: "notes",
                column: "title");

            migrationBuilder.AddForeignKey(
                name: "FK_user_note",
                table: "notes",
                column: "user_id",
                principalTable: "users",
                principalColumn: "id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
