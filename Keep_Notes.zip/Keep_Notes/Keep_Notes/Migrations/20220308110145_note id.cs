﻿using Microsoft.EntityFrameworkCore.Migrations;
using MySql.Data.EntityFrameworkCore.Metadata;

namespace Keep_Notes.Migrations
{
    public partial class noteid : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PRIMARY",
                table: "notes");

         
            migrationBuilder.AlterColumn<string>(
                name: "title",
                table: "notes",
                maxLength: 33,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(33)",
                oldMaxLength: 33);

            migrationBuilder.AddColumn<int>(
                name: "Id",
                table: "notes",
                nullable: false,
                defaultValue: 0)
                .Annotation("MySQL:ValueGenerationStrategy", MySQLValueGenerationStrategy.IdentityColumn);

            migrationBuilder.AddPrimaryKey(
                name: "PK_notes",
                table: "notes",
                column: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_notes",
                table: "notes");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "notes");

            migrationBuilder.RenameIndex(
                name: "IX_notes_user_id",
                table: "notes",
                newName: "FK_user_note");

            migrationBuilder.AlterColumn<string>(
                name: "title",
                table: "notes",
                type: "varchar(33)",
                maxLength: 33,
                nullable: false,
                oldClrType: typeof(string),
                oldMaxLength: 33,
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PRIMARY",
                table: "notes",
                columns: new[] { "title", "user_id" });
        }
    }
}
