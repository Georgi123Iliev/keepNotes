﻿namespace Keep_Notes.View
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.registration_Label = new System.Windows.Forms.Label();
            this.email_Label = new System.Windows.Forms.Label();
            this.passwordInput_Label = new System.Windows.Forms.Label();
            this.passwordConfirmation_Label = new System.Windows.Forms.Label();
            this.city_Label = new System.Windows.Forms.Label();
            this.age_Label = new System.Windows.Forms.Label();
            this.email_TextBox = new System.Windows.Forms.TextBox();
            this.password_TextBox = new System.Windows.Forms.TextBox();
            this.passwordConfirmation_TextBox = new System.Windows.Forms.TextBox();
            this.city_TextBox = new System.Windows.Forms.TextBox();
            this.age_TextBox = new System.Windows.Forms.TextBox();
            this.ready_Button = new System.Windows.Forms.Button();
            this.warning_Label = new System.Windows.Forms.Label();
            this.warning_age_Label = new System.Windows.Forms.Label();
            this.close_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // registration_Label
            // 
            this.registration_Label.AutoSize = true;
            this.registration_Label.Font = new System.Drawing.Font("Lucida Handwriting", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.registration_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.registration_Label.Location = new System.Drawing.Point(170, 9);
            this.registration_Label.Name = "registration_Label";
            this.registration_Label.Size = new System.Drawing.Size(229, 40);
            this.registration_Label.TabIndex = 0;
            this.registration_Label.Text = "Registration";
            // 
            // email_Label
            // 
            this.email_Label.AutoSize = true;
            this.email_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.email_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.email_Label.Location = new System.Drawing.Point(122, 69);
            this.email_Label.Name = "email_Label";
            this.email_Label.Size = new System.Drawing.Size(76, 51);
            this.email_Label.TabIndex = 1;
            this.email_Label.Text = "Email:";
            // 
            // passwordInput_Label
            // 
            this.passwordInput_Label.AutoSize = true;
            this.passwordInput_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.passwordInput_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.passwordInput_Label.Location = new System.Drawing.Point(98, 126);
            this.passwordInput_Label.Name = "passwordInput_Label";
            this.passwordInput_Label.Size = new System.Drawing.Size(107, 51);
            this.passwordInput_Label.TabIndex = 2;
            this.passwordInput_Label.Text = "Password:";
            // 
            // passwordConfirmation_Label
            // 
            this.passwordConfirmation_Label.AutoSize = true;
            this.passwordConfirmation_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.passwordConfirmation_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.passwordConfirmation_Label.Location = new System.Drawing.Point(7, 189);
            this.passwordConfirmation_Label.Name = "passwordConfirmation_Label";
            this.passwordConfirmation_Label.Size = new System.Drawing.Size(228, 51);
            this.passwordConfirmation_Label.TabIndex = 3;
            this.passwordConfirmation_Label.Text = "Password Confirmation:";
            // 
            // city_Label
            // 
            this.city_Label.AutoSize = true;
            this.city_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.city_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.city_Label.Location = new System.Drawing.Point(134, 252);
            this.city_Label.Name = "city_Label";
            this.city_Label.Size = new System.Drawing.Size(62, 51);
            this.city_Label.TabIndex = 4;
            this.city_Label.Text = "City:";
            // 
            // age_Label
            // 
            this.age_Label.AutoSize = true;
            this.age_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.age_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.age_Label.Location = new System.Drawing.Point(132, 313);
            this.age_Label.Name = "age_Label";
            this.age_Label.Size = new System.Drawing.Size(61, 51);
            this.age_Label.TabIndex = 5;
            this.age_Label.Text = "Age:";
            // 
            // email_TextBox
            // 
            this.email_TextBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.email_TextBox.Location = new System.Drawing.Point(233, 65);
            this.email_TextBox.Name = "email_TextBox";
            this.email_TextBox.Size = new System.Drawing.Size(201, 41);
            this.email_TextBox.TabIndex = 6;
            // 
            // password_TextBox
            // 
            this.password_TextBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.password_TextBox.Location = new System.Drawing.Point(233, 129);
            this.password_TextBox.Name = "password_TextBox";
            this.password_TextBox.Size = new System.Drawing.Size(201, 41);
            this.password_TextBox.TabIndex = 7;
            // 
            // passwordConfirmation_TextBox
            // 
            this.passwordConfirmation_TextBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.passwordConfirmation_TextBox.Location = new System.Drawing.Point(233, 192);
            this.passwordConfirmation_TextBox.Name = "passwordConfirmation_TextBox";
            this.passwordConfirmation_TextBox.Size = new System.Drawing.Size(201, 41);
            this.passwordConfirmation_TextBox.TabIndex = 8;
            // 
            // city_TextBox
            // 
            this.city_TextBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.city_TextBox.Location = new System.Drawing.Point(233, 255);
            this.city_TextBox.Name = "city_TextBox";
            this.city_TextBox.Size = new System.Drawing.Size(201, 41);
            this.city_TextBox.TabIndex = 9;
            // 
            // age_TextBox
            // 
            this.age_TextBox.Font = new System.Drawing.Font("Gabriola", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.age_TextBox.Location = new System.Drawing.Point(233, 313);
            this.age_TextBox.Name = "age_TextBox";
            this.age_TextBox.Size = new System.Drawing.Size(201, 41);
            this.age_TextBox.TabIndex = 10;
            // 
            // ready_Button
            // 
            this.ready_Button.BackColor = System.Drawing.Color.Gainsboro;
            this.ready_Button.Font = new System.Drawing.Font("Lucida Handwriting", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ready_Button.ForeColor = System.Drawing.Color.DarkBlue;
            this.ready_Button.Location = new System.Drawing.Point(122, 397);
            this.ready_Button.Name = "ready_Button";
            this.ready_Button.Size = new System.Drawing.Size(149, 41);
            this.ready_Button.TabIndex = 11;
            this.ready_Button.Text = "Ready";
            this.ready_Button.UseVisualStyleBackColor = false;
            this.ready_Button.Click += new System.EventHandler(this.ready_Button_Click);
            // 
            // warning_Label
            // 
            this.warning_Label.AutoSize = true;
            this.warning_Label.Font = new System.Drawing.Font("Gabriola", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.warning_Label.ForeColor = System.Drawing.Color.Firebrick;
            this.warning_Label.Location = new System.Drawing.Point(159, 357);
            this.warning_Label.Name = "warning_Label";
            this.warning_Label.Size = new System.Drawing.Size(0, 37);
            this.warning_Label.TabIndex = 13;
            // 
            // warning_age_Label
            // 
            this.warning_age_Label.AutoSize = true;
            this.warning_age_Label.Font = new System.Drawing.Font("Gabriola", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.warning_age_Label.ForeColor = System.Drawing.Color.Firebrick;
            this.warning_age_Label.Location = new System.Drawing.Point(78, 357);
            this.warning_age_Label.Name = "warning_age_Label";
            this.warning_age_Label.Size = new System.Drawing.Size(0, 37);
            this.warning_age_Label.TabIndex = 14;
            // 
            // close_Button
            // 
            this.close_Button.BackColor = System.Drawing.Color.Gainsboro;
            this.close_Button.Font = new System.Drawing.Font("Lucida Handwriting", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.close_Button.ForeColor = System.Drawing.Color.DarkBlue;
            this.close_Button.Location = new System.Drawing.Point(285, 397);
            this.close_Button.Name = "close_Button";
            this.close_Button.Size = new System.Drawing.Size(149, 41);
            this.close_Button.TabIndex = 15;
            this.close_Button.Text = "Close";
            this.close_Button.UseVisualStyleBackColor = false;
            this.close_Button.Click += new System.EventHandler(this.close_Button_Click);
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(569, 450);
            this.Controls.Add(this.close_Button);
            this.Controls.Add(this.warning_age_Label);
            this.Controls.Add(this.warning_Label);
            this.Controls.Add(this.ready_Button);
            this.Controls.Add(this.age_TextBox);
            this.Controls.Add(this.city_TextBox);
            this.Controls.Add(this.passwordConfirmation_TextBox);
            this.Controls.Add(this.password_TextBox);
            this.Controls.Add(this.email_TextBox);
            this.Controls.Add(this.age_Label);
            this.Controls.Add(this.city_Label);
            this.Controls.Add(this.passwordConfirmation_Label);
            this.Controls.Add(this.passwordInput_Label);
            this.Controls.Add(this.email_Label);
            this.Controls.Add(this.registration_Label);
            this.Name = "Register";
            this.Text = "Register";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Register_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label registration_Label;
        private System.Windows.Forms.Label email_Label;
        private System.Windows.Forms.Label passwordInput_Label;
        private System.Windows.Forms.Label passwordConfirmation_Label;
        private System.Windows.Forms.Label city_Label;
        private System.Windows.Forms.Label age_Label;
        private System.Windows.Forms.TextBox email_TextBox;
        private System.Windows.Forms.TextBox password_TextBox;
        private System.Windows.Forms.TextBox passwordConfirmation_TextBox;
        private System.Windows.Forms.TextBox city_TextBox;
        private System.Windows.Forms.TextBox age_TextBox;
        private System.Windows.Forms.Button ready_Button;
        private System.Windows.Forms.Label warning_Label;
        private System.Windows.Forms.Label warning_age_Label;
        private System.Windows.Forms.Button close_Button;
    }
}