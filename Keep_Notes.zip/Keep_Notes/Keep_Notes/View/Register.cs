﻿using Keep_Notes.Business_Logic;
using Keep_Notes.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Keep_Notes.View
{
    public partial class Register : Form
    {
        // Declared the business logic for the Register_Form
        static Logic_Register_Form logic_Register_Form;
        public signIn_Form signIn_Form;
        string[] str;
        public Register(signIn_Form sign_in)
        {
            InitializeComponent();
            signIn_Form = sign_in;
            logic_Register_Form = new Logic_Register_Form();
        }

        private void ready_Button_Click(object sender, EventArgs e)
        {

            
                str = logic_Register_Form.On_Ready_Button_Click(email_TextBox.Text, password_TextBox.Text, passwordConfirmation_TextBox.Text, city_TextBox.Text, age_TextBox.Text);
                if (str[0] == "READY")
                {
                    var ReadyForm = new Ready(this, str);
                    this.Hide();
                    ReadyForm.Show();
                warning_age_Label.Text = "";
                warning_Label.Text = "";
                }
                else
                {
                    warning_Label.Text = str[0];
                    warning_age_Label.Text = str[1];
                }
            
            
        }

        public void close_Button_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Register_FormClosing(object sender, FormClosingEventArgs e)
        {
            signIn_Form.Show();
        }
    }
}
