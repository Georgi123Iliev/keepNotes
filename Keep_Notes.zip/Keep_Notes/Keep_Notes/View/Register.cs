﻿using Keep_Notes.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Keep_Notes.View
{
    public partial class Register : Form
    {
        //Theses variables will be used in the Ready form
        public static string SetValueForText1 = "";
        public static string SetValueForText2 = "";
        public static string SetValueForText3 = "";
        public static string SetValueForText4 = "";
        public KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();

        public signIn_Form sign_in;

        public Register(signIn_Form sign_in)
        {
            InitializeComponent();
            this.sign_in = sign_in;
        }

        private void ready_Button_Click(object sender, EventArgs e)
        {
            Users newUser = new Users();
            //Checking the email
            Regex rgx = new Regex(@"^[a-zA-Z0-9_+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-]+$");
            MatchCollection matches = rgx.Matches(email_TextBox.Text);
            if (matches != null  && matches.Count == 1)
            {
                newUser.Username = email_TextBox.Text;

                //Checking the passsword
                if (password_TextBox.Text == passwordConfirmation_TextBox.Text && password_TextBox.Text.Length >= 5)
                {
                    newUser.Password = password_TextBox.Text;

                    bool cityFlag = false;
                    //Finding if there is such city
                    Cities city = (Cities)keepNotesDBContext.Cities.Where(c => c.Name == city_TextBox.Text).FirstOrDefault();
                    //If there is such city
                    if (city != null)
                    {
                        cityFlag = true;
                        newUser.CityId = city.Id;
                    }
                    //If there is not such city
                    else if(city_TextBox.Text.Length > 3)
                    {
                        cityFlag = true;
                        city = new Cities();
                        city.Name = city_TextBox.Text;

                        if (keepNotesDBContext.Cities.Count() != 0)
                            city.Id = keepNotesDBContext.Cities.OrderByDescending(p => p.Id).FirstOrDefault().Id + 1;
                        else
                            city.Id = 1;
                      
                        keepNotesDBContext.Cities.Add(city);
                        keepNotesDBContext.SaveChanges();
                        newUser.CityId = city.Id;
                    }
                else
                {
                    warning_Label.Text = "Enter a valid age";
                }
                if (cityFlag)
                {
                    //Defining the age group of the new user
                    //7-12
                    //13 - 18
                    //19 - 30
                    //31 - 50
                    //51 - 70
                    //70 +
                    if (age_TextBox.Text.Length > 0)
                    {
                        bool flag = true;
                        if (int.Parse(age_TextBox.Text) >= 71) newUser.AgeGroupId = 6;
                        else if (int.Parse(age_TextBox.Text) >= 51 && int.Parse(age_TextBox.Text) <= 70) newUser.AgeGroupId = 5;
                        else if (int.Parse(age_TextBox.Text) >= 31 && int.Parse(age_TextBox.Text) <= 50) newUser.AgeGroupId = 4;
                        else if (int.Parse(age_TextBox.Text) >= 19 && int.Parse(age_TextBox.Text) <= 30) newUser.AgeGroupId = 3;
                        else if (int.Parse(age_TextBox.Text) >= 13 && int.Parse(age_TextBox.Text) <= 18) newUser.AgeGroupId = 2;
                        else if (int.Parse(age_TextBox.Text) >= 7 && int.Parse(age_TextBox.Text) <= 12) newUser.AgeGroupId = 1;
                        else
                        {
                            flag = false;
                            warning_age_Label.Text = "You cannot make a registration if you are not at least 7 year old";
                        }

                        if (flag)
                        {
                                //Adding the new User
                                if (keepNotesDBContext.Users.Count() != 0)
                                    newUser.Id = keepNotesDBContext.Users.OrderByDescending(p => p.Id).FirstOrDefault().Id + 1;
                                else
                                    newUser.Id = 1;
                                SetValueForText1 = newUser.Username;
                                SetValueForText2 = newUser.Password;
                                SetValueForText3 = city_TextBox.Text;
                                SetValueForText4 = age_TextBox.Text;
                                var ReadyForm = new Ready(newUser, this);
                                this.Hide();
                                ReadyForm.Show();
                        }
                    }
                }
                    else warning_Label.Text = "Enter a valid city name";

                }
                //If the password is not correct
                else
                {
                    warning_Label.Text = "The password is not correct.";
                }

            }
            //If the email is not correct
            else
            {
                warning_Label.Text = "Wrong email. Enter a valid one!";
            }


        }

        public void close_Button_Click(object sender, EventArgs e)
        {
            ActiveForm.Close();
            sign_in.Show();
        }

        private void email_TextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
