﻿using Keep_Notes.Business_Logic;
using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Keep_Notes
{
    public partial class signIn_Form : Form
    {
        // Declared the business logic for the Sign_In_Form
        static Logic_SignIn_Form logic_SignIn_Form=new Logic_SignIn_Form();

        public signIn_Form()
        {
            InitializeComponent();
            
        }

        private void signIn_Button_Click(object sender, EventArgs e)
        {
            //set textboxes as paramether to reset them if needed
            logic_SignIn_Form.OnSignInButtonClick(email_TextBox, password_TextBox, warning_Label, this);
            
          
        }
        private void register_LinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            logic_SignIn_Form.register_LinkLabel_LinkClicked(this);
        }
    }
}
