﻿using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Keep_Notes
{
    public partial class signIn_Form : Form
    {
        public Users theUser;
        public KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();
        public signIn_Form()
        {
            InitializeComponent();
        }

        private void signIn_Button_Click(object sender, EventArgs e)
        {
            //Checking if the required user exists in the database
            var userExist = keepNotesDBContext.Users
                .Where(kN => kN.Username.Equals(email_TextBox.Text))
                .Where(kN => kN.Password.Equals(password_TextBox.Text))
                .ToList()
                .FirstOrDefault();
            //Checking if the required user exists in the database
            if (userExist == null)
            {
                warning_Label.Text = "Wrong password or email";
            }
            else
            {
                // theUser should be used for the notes
                theUser = (Users)userExist;
            }
        }
        private void register_LinkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var registerForm = new Register();
            registerForm.Show();
        }
    }
}
