﻿using Keep_Notes.Business_Logic;
using Keep_Notes.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
namespace Keep_Notes.View
{
    public partial class NotesMenu : Form
    {
        Users user;
        Logic_NotesMenu_Form logic_NotesMenu = new Logic_NotesMenu_Form();
        signIn_Form signIn;
        public NotesMenu(Users User,signIn_Form signIn)
        {
            InitializeComponent();
            user = User;
            
            
            //so the user can only pick one note at a time
            NotesBox.SelectionMode = SelectionMode.One;
            CategoriesListBox.SelectionMode = SelectionMode.One;
            this.signIn = signIn;
        }

       

        private void NotesBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (NotesBox.SelectedItem != null)// prevent empty clicks
            {
                
                PreviewLabel.Text= logic_NotesMenu.DisplayNotePreview(NotesBox.SelectedItem.ToString());
                WarningLabel.Text = "";
            }
        }

        private void NotesMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            signIn.Show();
        }

        private void Delete_button_Click(object sender, EventArgs e)
        {
            if (NotesBox.SelectedItem == null)
            {
                WarningLabel.Text = "No note selected!";
                return;
            }
            DialogResult res = MessageBox.Show("Are you sure you want to delete the selected note?", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (res == DialogResult.OK)
            {
                logic_NotesMenu.DeleteNode(NotesBox.SelectedItem.ToString());
                logic_NotesMenu.UpdateNoteList(user.Id);
                WarningLabel.Text = "";
                PreviewLabel.Text = "";
            }
            
           
           
        }

        private void CategoriesListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            NotesBox.Items.Clear();

            foreach (var i in logic_NotesMenu.UpdateNoteList(user.Id, CategoriesListBox.SelectedItem.ToString()))
                NotesBox.Items.Add(i.ToString());
            PreviewLabel.Text = "";
            
        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
           
                Close();
           
        }

        private void NotesMenu_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure you want to log out?", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (res == DialogResult.Cancel)
            {
                e.Cancel=true;
            }
            
        }

        private void NewNoteButton_Click(object sender, EventArgs e)
        {
            NoteEditor noteEditor = new NoteEditor(user.Id,this);
            noteEditor.Show();
            this.Hide();

        }

        private void NotesMenu_Shown(object sender, EventArgs e)
        {
            foreach(var i in logic_NotesMenu.UpdateNoteList(user.Id))
                NotesBox.Items.Add(i);
        }
    }
}
