﻿using Keep_Notes.Business_Logic;
using Keep_Notes.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
namespace Keep_Notes.View
{
    public partial class NotesMenu : Form
    {
        Users user;
        Logic_NotesMenu_Form logic_NotesMenu = new Logic_NotesMenu_Form();
        signIn_Form signIn;
        bool currentNoteLocked=false;
        int currentNoteId=-1;
        public NotesMenu(Users User,signIn_Form signIn)
        {
            InitializeComponent();
            user = User;

           
            //so the user can only pick one note at a time
            NotesBox.SelectionMode = SelectionMode.One;
            CategoriesListBox.SelectionMode = SelectionMode.One;
            this.signIn = signIn;
        }

       

        private void NotesBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (NotesBox.SelectedItem != null)// prevent empty clicks
            {
                if (logic_NotesMenu.isPrivate(NotesBox.SelectedItem.ToString(), user.Id))
                {
                    WarningLabel.Text = "The note is locked! \n Enter password to unlock it!";
                    WarningLabel.TextAlign = ContentAlignment.MiddleCenter;
                    PasswordTextBox.Show();
                    PasswordEntryButton.Show();
                    currentNoteLocked = true;
                    

                }
                else
                {
                    PasswordTextBox.Hide();
                    PasswordEntryButton.Hide();
                    PasswordTextBox.Text = "";
                    
                    WarningLabel.Text = "";
                    currentNoteLocked = false;
                }
                PreviewLabel.Text = logic_NotesMenu.DisplayNotePreview(NotesBox.SelectedItem.ToString(), user.Id,currentNoteLocked);
                PreviewLabel.BackColor = logic_NotesMenu.DisplayNoteColor(NotesBox.SelectedItem.ToString(), user.Id);
                currentNoteId = logic_NotesMenu.getId(NotesBox.SelectedItem.ToString(),user.Id);
            }
        }

        private void NotesMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            signIn.Show();
        }

        private void Delete_button_Click(object sender, EventArgs e)
        {
            if (currentNoteLocked)
            {
                return;
                
            }
            if (NotesBox.SelectedItem == null)
            {
                WarningLabel.Text = "No note selected!";
                WarningLabel.TextAlign = ContentAlignment.MiddleCenter;
                return;
            }
            DialogResult res = MessageBox.Show("Are you sure you want to delete the selected note?", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (res == DialogResult.OK)
            {
                logic_NotesMenu.DeleteNode(NotesBox.SelectedItem.ToString(),user.Id);
                NotesBox.Items.Clear();
                foreach(var i in   logic_NotesMenu.UpdateNoteList(user.Id))
                {
                    NotesBox.Items.Add(i);
                }
                WarningLabel.Text = "";
                PreviewLabel.Text = "";
                PreviewLabel.BackColor = Color.White;
            }
            
           
           
        }

        private void CategoriesListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            NotesBox.Items.Clear();

            foreach (var i in logic_NotesMenu.UpdateNoteList(user.Id, CategoriesListBox.SelectedItem.ToString()))
                NotesBox.Items.Add(i.ToString());
            PreviewLabel.Text = "";
            PreviewLabel.BackColor = Color.White;
            
        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
           
                Close();
           
        }

        private void NotesMenu_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure you want to log out?", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (res == DialogResult.Cancel)
            {
                e.Cancel=true;
            }
            
        }

        private void NewNoteButton_Click(object sender, EventArgs e)
        {
            NoteEditor noteEditor = new NoteEditor(user.Id,this,"New",-1);
            noteEditor.Show();
            this.Hide();

        }

        private void NotesMenu_Shown(object sender, EventArgs e)
        {
          
        }

        private void NotesMenu_VisibleChanged(object sender, EventArgs e)
        {
            if (this.Visible)
            {
                
                NotesBox.Items.Clear();
                PasswordTextBox.Hide();
                PasswordEntryButton.Hide();
                PasswordTextBox.Text = "";
                WarningLabel.Text = "";
                PreviewLabel.Text = "";
                PreviewLabel.BackColor = Color.White;
                foreach (var i in logic_NotesMenu.UpdateNoteList(user.Id))
                    NotesBox.Items.Add(i);
                currentNoteId = -1;
            }


        }

        private void PasswordEntryButton_Click(object sender, EventArgs e)
        {
            if (logic_NotesMenu.PasswordIsCorrect(NotesBox.SelectedItem.ToString(), user.Id, PasswordTextBox.Text))
            {
               PreviewLabel.Text= logic_NotesMenu.DisplayNotePreview(NotesBox.SelectedItem.ToString(), user.Id,false);

                PasswordTextBox.Hide();
                PasswordEntryButton.Hide();
                PasswordTextBox.Text = "";

                WarningLabel.Text = "";
                currentNoteLocked = false;
            }
            else
            {
                WarningLabel.Text = "Wrong password!";
                WarningLabel.TextAlign = ContentAlignment.MiddleCenter;
            }

        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            if(NotesBox.SelectedItem==null)
            {

                PasswordTextBox.Hide();
                PasswordEntryButton.Hide();
                PasswordTextBox.Text = "";

                WarningLabel.Text = "Select a note to edit";
                WarningLabel.TextAlign = ContentAlignment.MiddleCenter;
                return;
            }    
            if(currentNoteLocked==false)
            {
                NoteEditor noteEditor = new NoteEditor(user.Id, this, "Edit",currentNoteId);
                noteEditor.Show();
                this.Hide();
                currentNoteId = -1;
                return;
            }

        }

        private void PasswordTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
