﻿namespace Keep_Notes
{
    partial class Ready
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.registration_Label = new System.Windows.Forms.Label();
            this.age_Label = new System.Windows.Forms.Label();
            this.city_Label = new System.Windows.Forms.Label();
            this.passwordInput_Label = new System.Windows.Forms.Label();
            this.email_Label = new System.Windows.Forms.Label();
            this.ageOutput_Label = new System.Windows.Forms.Label();
            this.cityOutput_Label = new System.Windows.Forms.Label();
            this.passwordOutput_Label = new System.Windows.Forms.Label();
            this.emailOutput_Label = new System.Windows.Forms.Label();
            this.edit_Button = new System.Windows.Forms.Button();
            this.ready_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // registration_Label
            // 
            this.registration_Label.AutoSize = true;
            this.registration_Label.Font = new System.Drawing.Font("Lucida Handwriting", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.registration_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.registration_Label.Location = new System.Drawing.Point(208, 42);
            this.registration_Label.Name = "registration_Label";
            this.registration_Label.Size = new System.Drawing.Size(141, 40);
            this.registration_Label.TabIndex = 1;
            this.registration_Label.Text = "Ready?";
            // 
            // age_Label
            // 
            this.age_Label.AutoSize = true;
            this.age_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.age_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.age_Label.Location = new System.Drawing.Point(182, 294);
            this.age_Label.Name = "age_Label";
            this.age_Label.Size = new System.Drawing.Size(61, 51);
            this.age_Label.TabIndex = 9;
            this.age_Label.Text = "Age:";
            // 
            // city_Label
            // 
            this.city_Label.AutoSize = true;
            this.city_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.city_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.city_Label.Location = new System.Drawing.Point(184, 233);
            this.city_Label.Name = "city_Label";
            this.city_Label.Size = new System.Drawing.Size(62, 51);
            this.city_Label.TabIndex = 8;
            this.city_Label.Text = "City:";
            // 
            // passwordInput_Label
            // 
            this.passwordInput_Label.AutoSize = true;
            this.passwordInput_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.passwordInput_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.passwordInput_Label.Location = new System.Drawing.Point(147, 170);
            this.passwordInput_Label.Name = "passwordInput_Label";
            this.passwordInput_Label.Size = new System.Drawing.Size(107, 51);
            this.passwordInput_Label.TabIndex = 7;
            this.passwordInput_Label.Text = "Password:";
            // 
            // email_Label
            // 
            this.email_Label.AutoSize = true;
            this.email_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.email_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.email_Label.Location = new System.Drawing.Point(172, 113);
            this.email_Label.Name = "email_Label";
            this.email_Label.Size = new System.Drawing.Size(76, 51);
            this.email_Label.TabIndex = 6;
            this.email_Label.Text = "Email:";
            // 
            // ageOutput_Label
            // 
            this.ageOutput_Label.AutoSize = true;
            this.ageOutput_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ageOutput_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.ageOutput_Label.Location = new System.Drawing.Point(258, 294);
            this.ageOutput_Label.Name = "ageOutput_Label";
            this.ageOutput_Label.Size = new System.Drawing.Size(0, 51);
            this.ageOutput_Label.TabIndex = 13;
            // 
            // cityOutput_Label
            // 
            this.cityOutput_Label.AutoSize = true;
            this.cityOutput_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cityOutput_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.cityOutput_Label.Location = new System.Drawing.Point(247, 233);
            this.cityOutput_Label.Name = "cityOutput_Label";
            this.cityOutput_Label.Size = new System.Drawing.Size(0, 51);
            this.cityOutput_Label.TabIndex = 12;
            // 
            // passwordOutput_Label
            // 
            this.passwordOutput_Label.AutoSize = true;
            this.passwordOutput_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.passwordOutput_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.passwordOutput_Label.Location = new System.Drawing.Point(254, 170);
            this.passwordOutput_Label.Name = "passwordOutput_Label";
            this.passwordOutput_Label.Size = new System.Drawing.Size(0, 51);
            this.passwordOutput_Label.TabIndex = 11;
            // 
            // emailOutput_Label
            // 
            this.emailOutput_Label.AutoSize = true;
            this.emailOutput_Label.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.emailOutput_Label.ForeColor = System.Drawing.Color.DarkBlue;
            this.emailOutput_Label.Location = new System.Drawing.Point(242, 113);
            this.emailOutput_Label.Name = "emailOutput_Label";
            this.emailOutput_Label.Size = new System.Drawing.Size(0, 51);
            this.emailOutput_Label.TabIndex = 10;
            // 
            // edit_Button
            // 
            this.edit_Button.BackColor = System.Drawing.Color.Gainsboro;
            this.edit_Button.Font = new System.Drawing.Font("Lucida Handwriting", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.edit_Button.ForeColor = System.Drawing.Color.DarkBlue;
            this.edit_Button.Location = new System.Drawing.Point(286, 386);
            this.edit_Button.Name = "edit_Button";
            this.edit_Button.Size = new System.Drawing.Size(149, 41);
            this.edit_Button.TabIndex = 17;
            this.edit_Button.Text = "Edit";
            this.edit_Button.UseVisualStyleBackColor = false;
            this.edit_Button.Click += new System.EventHandler(this.edit_Button_Click);
            // 
            // ready_Button
            // 
            this.ready_Button.BackColor = System.Drawing.Color.Gainsboro;
            this.ready_Button.Font = new System.Drawing.Font("Lucida Handwriting", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ready_Button.ForeColor = System.Drawing.Color.DarkBlue;
            this.ready_Button.Location = new System.Drawing.Point(123, 386);
            this.ready_Button.Name = "ready_Button";
            this.ready_Button.Size = new System.Drawing.Size(149, 41);
            this.ready_Button.TabIndex = 16;
            this.ready_Button.Text = "Ready";
            this.ready_Button.UseVisualStyleBackColor = false;
            this.ready_Button.Click += new System.EventHandler(this.ready_Button_Click);
            // 
            // Ready
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(568, 450);
            this.Controls.Add(this.edit_Button);
            this.Controls.Add(this.ready_Button);
            this.Controls.Add(this.ageOutput_Label);
            this.Controls.Add(this.cityOutput_Label);
            this.Controls.Add(this.passwordOutput_Label);
            this.Controls.Add(this.emailOutput_Label);
            this.Controls.Add(this.age_Label);
            this.Controls.Add(this.city_Label);
            this.Controls.Add(this.passwordInput_Label);
            this.Controls.Add(this.email_Label);
            this.Controls.Add(this.registration_Label);
            this.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.Name = "Ready";
            this.Text = "Ready";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Ready_FormClosing);
            this.Load += new System.EventHandler(this.Ready_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label registration_Label;
        private System.Windows.Forms.Label age_Label;
        private System.Windows.Forms.Label city_Label;
        private System.Windows.Forms.Label passwordInput_Label;
        private System.Windows.Forms.Label email_Label;
        private System.Windows.Forms.Label ageOutput_Label;
        private System.Windows.Forms.Label cityOutput_Label;
        private System.Windows.Forms.Label passwordOutput_Label;
        private System.Windows.Forms.Label emailOutput_Label;
        private System.Windows.Forms.Button edit_Button;
        private System.Windows.Forms.Button ready_Button;
    }
}