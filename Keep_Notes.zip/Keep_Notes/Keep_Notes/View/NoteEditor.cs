﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Keep_Notes.View
{
    
    public partial class NoteEditor : Form
    {
        int UserId;
        NotesMenu notesMenu;
        
        public NoteEditor(int userId,NotesMenu notes)
        {
            InitializeComponent();
            UserId = userId;
            notesMenu = notes;
            
            PrivateComboBox.DataSource = new ComboItem[]
            {
                new ComboItem{str="No",val=false },
                new ComboItem{str="Yes",val=true }

            };
            PrivateComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            
            
        }

        private void NoteEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            
            notesMenu.Show();
        }
    }
    //for combobox
    class ComboItem
    {
        public string str { get; set; }
        public bool val { get; set; }
    }
}
