﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Linq;
using Keep_Notes.Business_Logic;
namespace Keep_Notes.View
{
    
    public partial class NoteEditor : Form
    {
        int UserId;
        NotesMenu notesMenu;
        INoteLogic logic;
        int NoteId;
        bool saved;
        public NoteEditor(int userId,NotesMenu notes,string mode,int noteId)
        {
            // Making the look of the editor
            InitializeComponent();
            UserId = userId;
            notesMenu = notes;
            NoteId = noteId;
            PrivateComboBox.DataSource = new Private[]
            {
                new Private{str="No",val=false },
                new Private{str="Yes",val=true }

            };
            CategoryComboBox.DataSource = new Category[]
            {   new Category{str="--Select--",val="Other" },
                new Category{str="Cooking",val="Cooking" },
                new Category{str="Studying",val="Studying" },
                new Category{str="Articles",val="Articles" },
                new Category{str="Books",val="Books" },
                 new Category{str="Other",val="Other" }

            };
            BackgroundComboBox.DataSource = new Background[]
            {
            new Background{str="--Select--",val="White" },
            new Background{str="Green",val="Green" },
            new Background{str="Blue",val="Blue" },
            new Background{str="White",val="White" }



            };
            PrivateComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            CategoryComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            BackgroundComboBox.DropDownStyle = ComboBoxStyle.DropDownList;

            //Checking the clicked mode
            if (mode == "New")
            {
                logic = new NewNote_Logic();
                PasswordTextBox.Hide();
                PasswordLabel.Hide();
                saved = false;
            }
            else if (mode == "Edit")
            {
                logic = new EditNote_Logic();
               
                //fill up the form
                var NoteData = logic.StartUp(NoteId);
                TitleTextBox.Text = NoteData[0];
                NoteTextBox.Text = NoteData[1];
                if (NoteData[2] == "True")
                {
                    PrivateComboBox.SelectedIndex = 1;
                    PasswordTextBox.Text = NoteData[3];
                }
                else
                {
                    PrivateComboBox.SelectedIndex = 0;
                    PasswordTextBox.Hide();
                    PasswordLabel.Hide();
                }
                CategoryComboBox.SelectedIndex = CategoryComboBox.FindString(NoteData[4]);
                BackgroundComboBox.SelectedIndex = BackgroundComboBox.FindString(NoteData[5]);
                NoteTextBox.BackColor = DisplayNoteColor();
                saved = true;

            }


            
            
            
           
        }
        public System.Drawing.Color DisplayNoteColor()
        {
           
            switch (BackgroundComboBox.SelectedValue)
            {

                case "Green": return System.Drawing.Color.LimeGreen;
                case "Blue": return System.Drawing.Color.Blue;
                default: return System.Drawing.Color.White;
            }



        }
        private void NoteEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
           
            if (saved)
                notesMenu.Show();
            else
            {
                DialogResult res = MessageBox.Show(logic.NotSavedMessage, "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (res == DialogResult.Cancel)
                {
                    e.Cancel = true;
                }
                else
                {
                    notesMenu.Show();
                }
            }
        }
        

        // Composing the Forms
        private void PrivateComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((bool)PrivateComboBox.SelectedValue == true)
            {
                PasswordLabel.Show();
                PasswordTextBox.Show();
            }
            else
            {
                PasswordLabel.Hide();
                PasswordTextBox.Hide();
            }

            saved = false;
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            // Making the messages
            if ((bool)PrivateComboBox.SelectedValue == true && (PasswordTextBox.Text.Length < 5 || PasswordTextBox.Text.Length > 16))
            {
                WarningLabel.Text = "Password must be between \n 5 and 16 characters long";
                return;
            }

            string msg = logic.Save(UserId, TitleTextBox.Text, NoteTextBox.Text, (bool)PrivateComboBox.SelectedValue, CategoryComboBox.SelectedValue.ToString(), BackgroundComboBox.SelectedValue.ToString(), PasswordTextBox.Text, NoteId);
            if (msg == "Invalid title")
                WarningLabel.Text = "There is already a note with that title";
            else if (msg =="Note Saved")
            {
                WarningLabel.Text = msg;
                if(logic.GetType().Name == "NewNote_Logic")
                logic = new EditNote_Logic();
                saved = true;             
            }           
        }
      
        private void BackgroundComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            NoteTextBox.BackColor = DisplayNoteColor();
            saved = false;
        }

        private void TitleTextBox_TextChanged(object sender, EventArgs e)
        {
            saved = false;
        }

        private void NoteTextBox_TextChanged(object sender, EventArgs e)
        {
            saved = false;
        }

        private void PasswordTextBox_TextChanged(object sender, EventArgs e)
        {
            saved = false;
        }

        private void CategoryComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            saved = false;
        }
    }
    //for combobox
    class Private
    {
        public string str { get; set; }
        public bool val { get; set; }
    }
    class Category
    {
        public string str { get; set; }
        public string val { get; set; }
    }
    class Background
    {
        public string str { get; set; }
        public string val { get; set; }
    }

}
