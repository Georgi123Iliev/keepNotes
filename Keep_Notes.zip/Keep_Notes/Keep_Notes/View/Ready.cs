﻿using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Keep_Notes
{
    public partial class Ready : Form
    {
        public static KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();
        public Register register;
        public static bool IsReady = true;
        public Users user;
        public Ready(Users users, Register register)
        {
            InitializeComponent();
            this.user = users;
            this.register = register;
        }

        private void Ready_Load(object sender, EventArgs e)
        {
            //Setting the public variables from the register form here
            emailOutput_Label.Text = Register.SetValueForText1;
            passwordOutput_Label.Text = Register.SetValueForText2;
            cityOutput_Label.Text = Register.SetValueForText3;
            ageOutput_Label.Text = Register.SetValueForText4;
        }

        private void ready_Button_Click(object sender, EventArgs e)
        {
            //If the costumer is ready with the registration this form and the registration form should be closed
            keepNotesDBContext.Users.Add(this.user);
            keepNotesDBContext.SaveChanges();
            ActiveForm.Close();
            register.sign_in.Show();
            register.Close();

        }

        private void edit_Button_Click(object sender, EventArgs e)
        {
            //If the costumer is not ready with the registration this form should be closed and the registration form shold stay active
            ActiveForm.Close();
            register.Show();
        }
    }
}
