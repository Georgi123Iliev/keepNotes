﻿using Keep_Notes.Business_Logic;
using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Keep_Notes
{
    public partial class Ready : Form
    {
        // Declared the business logic for the Ready_Form
        static Logic_Ready_Form logic_Ready_Form;
        public Ready(Users users, Register register, Logic_Register_Form logic_Register_Form)
        {
            InitializeComponent();
            logic_Ready_Form = new Logic_Ready_Form(users, register, logic_Register_Form);
        }

        private void Ready_Load(object sender, EventArgs e)
        {
            logic_Ready_Form.On_Ready_Load(emailOutput_Label, passwordOutput_Label, cityOutput_Label, ageOutput_Label);
        }

        private void ready_Button_Click(object sender, EventArgs e)
        {
            logic_Ready_Form.On_Ready_Button_Click(this);
        }

        private void edit_Button_Click(object sender, EventArgs e)
        {
            logic_Ready_Form.On_Edit_Button_Click(this);
        }
    }
}
