﻿
namespace Keep_Notes.View
{
    partial class NoteEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TitleLabel = new System.Windows.Forms.Label();
            this.TitleTextBox = new System.Windows.Forms.TextBox();
            this.NoteTextLabel = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.PrivateComboBox = new System.Windows.Forms.ComboBox();
            this.LabelPrivate = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Location = new System.Drawing.Point(13, 13);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(38, 20);
            this.TitleLabel.TabIndex = 0;
            this.TitleLabel.Text = "Title";
            // 
            // TitleTextBox
            // 
            this.TitleTextBox.Location = new System.Drawing.Point(13, 36);
            this.TitleTextBox.Name = "TitleTextBox";
            this.TitleTextBox.Size = new System.Drawing.Size(158, 27);
            this.TitleTextBox.TabIndex = 1;
            // 
            // NoteTextLabel
            // 
            this.NoteTextLabel.AutoSize = true;
            this.NoteTextLabel.Location = new System.Drawing.Point(13, 70);
            this.NoteTextLabel.Name = "NoteTextLabel";
            this.NoteTextLabel.Size = new System.Drawing.Size(71, 20);
            this.NoteTextLabel.TabIndex = 2;
            this.NoteTextLabel.Text = "Note text";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(13, 94);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(341, 344);
            this.textBox1.TabIndex = 3;
            // 
            // PrivateComboBox
            // 
            this.PrivateComboBox.DisplayMember = "str";
            this.PrivateComboBox.FormattingEnabled = true;
            this.PrivateComboBox.Location = new System.Drawing.Point(483, 27);
            this.PrivateComboBox.Name = "PrivateComboBox";
            this.PrivateComboBox.Size = new System.Drawing.Size(151, 28);
            this.PrivateComboBox.TabIndex = 4;
            this.PrivateComboBox.ValueMember = "val";
            // 
            // LabelPrivate
            // 
            this.LabelPrivate.AutoSize = true;
            this.LabelPrivate.Location = new System.Drawing.Point(389, 27);
            this.LabelPrivate.Name = "LabelPrivate";
            this.LabelPrivate.Size = new System.Drawing.Size(54, 20);
            this.LabelPrivate.TabIndex = 5;
            this.LabelPrivate.Text = "Private";
            // 
            // NoteEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LabelPrivate);
            this.Controls.Add(this.PrivateComboBox);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.NoteTextLabel);
            this.Controls.Add(this.TitleTextBox);
            this.Controls.Add(this.TitleLabel);
            this.Name = "NoteEditor";
            this.Text = "NoteEditor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.NoteEditor_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.TextBox TitleTextBox;
        private System.Windows.Forms.Label NoteTextLabel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox PrivateComboBox;
        private System.Windows.Forms.Label LabelPrivate;
    }
}