﻿
namespace Keep_Notes.View
{
    partial class NotesMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NotesBox = new System.Windows.Forms.ListBox();
            this.PreviewLabel = new System.Windows.Forms.Label();
            this.Delete_button = new System.Windows.Forms.Button();
            this.WarningLabel = new System.Windows.Forms.Label();
            this.CategoriesListBox = new System.Windows.Forms.ListBox();
            this.LogOutButton = new System.Windows.Forms.Button();
            this.NewNoteButton = new System.Windows.Forms.Button();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.PasswordEntryButton = new System.Windows.Forms.Button();
            this.EditButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // NotesBox
            // 
            this.NotesBox.FormattingEnabled = true;
            this.NotesBox.ItemHeight = 50;
            this.NotesBox.Location = new System.Drawing.Point(12, 52);
            this.NotesBox.Margin = new System.Windows.Forms.Padding(4, 8, 4, 8);
            this.NotesBox.Name = "NotesBox";
            this.NotesBox.Size = new System.Drawing.Size(220, 354);
            this.NotesBox.TabIndex = 0;
            this.NotesBox.SelectedIndexChanged += new System.EventHandler(this.NotesBox_SelectedIndexChanged);
            // 
            // PreviewLabel
            // 
            this.PreviewLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PreviewLabel.Location = new System.Drawing.Point(267, 52);
            this.PreviewLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PreviewLabel.Name = "PreviewLabel";
            this.PreviewLabel.Size = new System.Drawing.Size(221, 354);
            this.PreviewLabel.TabIndex = 1;
            // 
            // Delete_button
            // 
            this.Delete_button.BackColor = System.Drawing.Color.Gainsboro;
            this.Delete_button.Location = new System.Drawing.Point(756, 232);
            this.Delete_button.Margin = new System.Windows.Forms.Padding(4, 8, 4, 8);
            this.Delete_button.Name = "Delete_button";
            this.Delete_button.Size = new System.Drawing.Size(221, 72);
            this.Delete_button.TabIndex = 2;
            this.Delete_button.Text = "Delete";
            this.Delete_button.UseVisualStyleBackColor = false;
            this.Delete_button.Click += new System.EventHandler(this.Delete_button_Click);
            // 
            // WarningLabel
            // 
            this.WarningLabel.AutoSize = true;
            this.WarningLabel.Location = new System.Drawing.Point(496, 97);
            this.WarningLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.WarningLabel.Name = "WarningLabel";
            this.WarningLabel.Size = new System.Drawing.Size(0, 51);
            this.WarningLabel.TabIndex = 3;
            // 
            // CategoriesListBox
            // 
            this.CategoriesListBox.FormattingEnabled = true;
            this.CategoriesListBox.ItemHeight = 50;
            this.CategoriesListBox.Items.AddRange(new object[] {
            "Any",
            "Cooking",
            "Studying",
            "Articles",
            "Books",
            "Other"});
            this.CategoriesListBox.Location = new System.Drawing.Point(509, 297);
            this.CategoriesListBox.Margin = new System.Windows.Forms.Padding(4, 8, 4, 8);
            this.CategoriesListBox.Name = "CategoriesListBox";
            this.CategoriesListBox.Size = new System.Drawing.Size(217, 54);
            this.CategoriesListBox.TabIndex = 4;
            this.CategoriesListBox.SelectedIndexChanged += new System.EventHandler(this.CategoriesListBox_SelectedIndexChanged);
            // 
            // LogOutButton
            // 
            this.LogOutButton.BackColor = System.Drawing.Color.Gainsboro;
            this.LogOutButton.Location = new System.Drawing.Point(756, 22);
            this.LogOutButton.Margin = new System.Windows.Forms.Padding(4, 8, 4, 8);
            this.LogOutButton.Name = "LogOutButton";
            this.LogOutButton.Size = new System.Drawing.Size(221, 72);
            this.LogOutButton.TabIndex = 5;
            this.LogOutButton.Text = "Log Out";
            this.LogOutButton.UseVisualStyleBackColor = false;
            this.LogOutButton.Click += new System.EventHandler(this.LogOutButton_Click);
            // 
            // NewNoteButton
            // 
            this.NewNoteButton.BackColor = System.Drawing.Color.Gainsboro;
            this.NewNoteButton.Location = new System.Drawing.Point(756, 334);
            this.NewNoteButton.Margin = new System.Windows.Forms.Padding(4, 8, 4, 8);
            this.NewNoteButton.Name = "NewNoteButton";
            this.NewNoteButton.Size = new System.Drawing.Size(221, 72);
            this.NewNoteButton.TabIndex = 6;
            this.NewNoteButton.Text = "New";
            this.NewNoteButton.UseVisualStyleBackColor = false;
            this.NewNoteButton.Click += new System.EventHandler(this.NewNoteButton_Click);
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Location = new System.Drawing.Point(534, 28);
            this.PasswordTextBox.Margin = new System.Windows.Forms.Padding(4, 8, 4, 8);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(170, 53);
            this.PasswordTextBox.TabIndex = 7;
            // 
            // PasswordEntryButton
            // 
            this.PasswordEntryButton.BackColor = System.Drawing.Color.Gainsboro;
            this.PasswordEntryButton.Location = new System.Drawing.Point(557, 194);
            this.PasswordEntryButton.Margin = new System.Windows.Forms.Padding(4, 8, 4, 8);
            this.PasswordEntryButton.Name = "PasswordEntryButton";
            this.PasswordEntryButton.Size = new System.Drawing.Size(129, 72);
            this.PasswordEntryButton.TabIndex = 8;
            this.PasswordEntryButton.Text = "Enter";
            this.PasswordEntryButton.UseVisualStyleBackColor = false;
            this.PasswordEntryButton.Click += new System.EventHandler(this.PasswordEntryButton_Click);
            // 
            // EditButton
            // 
            this.EditButton.BackColor = System.Drawing.Color.Gainsboro;
            this.EditButton.Location = new System.Drawing.Point(756, 124);
            this.EditButton.Margin = new System.Windows.Forms.Padding(4, 8, 4, 8);
            this.EditButton.Name = "EditButton";
            this.EditButton.Size = new System.Drawing.Size(221, 72);
            this.EditButton.TabIndex = 9;
            this.EditButton.Text = "Edit";
            this.EditButton.UseVisualStyleBackColor = false;
            this.EditButton.Click += new System.EventHandler(this.EditButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, -7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 51);
            this.label1.TabIndex = 10;
            this.label1.Text = "Notes";
            // 
            // NotesMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 50F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(1005, 432);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.EditButton);
            this.Controls.Add(this.PasswordEntryButton);
            this.Controls.Add(this.PasswordTextBox);
            this.Controls.Add(this.NewNoteButton);
            this.Controls.Add(this.LogOutButton);
            this.Controls.Add(this.CategoriesListBox);
            this.Controls.Add(this.WarningLabel);
            this.Controls.Add(this.Delete_button);
            this.Controls.Add(this.PreviewLabel);
            this.Controls.Add(this.NotesBox);
            this.Font = new System.Drawing.Font("Gabriola", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.Color.DarkBlue;
            this.Margin = new System.Windows.Forms.Padding(4, 8, 4, 8);
            this.Name = "NotesMenu";
            this.Text = "NotesMenu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.NotesMenu_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.NotesMenu_FormClosed);
            this.Shown += new System.EventHandler(this.NotesMenu_Shown);
            this.VisibleChanged += new System.EventHandler(this.NotesMenu_VisibleChanged);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox NotesBox;
        private System.Windows.Forms.Label PreviewLabel;
        private System.Windows.Forms.Button Delete_button;
        private System.Windows.Forms.Label WarningLabel;
        private System.Windows.Forms.ListBox CategoriesListBox;
        private System.Windows.Forms.Button LogOutButton;
        private System.Windows.Forms.Button NewNoteButton;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.Button PasswordEntryButton;
        private System.Windows.Forms.Button EditButton;
        private System.Windows.Forms.Label label1;
    }
}