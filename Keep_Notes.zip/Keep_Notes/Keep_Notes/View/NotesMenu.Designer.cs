﻿
namespace Keep_Notes.View
{
    partial class NotesMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NotesBox = new System.Windows.Forms.ListBox();
            this.PreviewLabel = new System.Windows.Forms.Label();
            this.Delete_button = new System.Windows.Forms.Button();
            this.WarningLabel = new System.Windows.Forms.Label();
            this.CategoriesListBox = new System.Windows.Forms.ListBox();
            this.LogOutButton = new System.Windows.Forms.Button();
            this.NewNoteButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // NotesBox
            // 
            this.NotesBox.FormattingEnabled = true;
            this.NotesBox.ItemHeight = 20;
            this.NotesBox.Location = new System.Drawing.Point(12, 12);
            this.NotesBox.Name = "NotesBox";
            this.NotesBox.Size = new System.Drawing.Size(161, 284);
            this.NotesBox.TabIndex = 0;
            this.NotesBox.SelectedIndexChanged += new System.EventHandler(this.NotesBox_SelectedIndexChanged);
            // 
            // PreviewLabel
            // 
            this.PreviewLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PreviewLabel.Location = new System.Drawing.Point(187, 21);
            this.PreviewLabel.Name = "PreviewLabel";
            this.PreviewLabel.Size = new System.Drawing.Size(161, 120);
            this.PreviewLabel.TabIndex = 1;
            // 
            // Delete_button
            // 
            this.Delete_button.Location = new System.Drawing.Point(187, 160);
            this.Delete_button.Name = "Delete_button";
            this.Delete_button.Size = new System.Drawing.Size(161, 29);
            this.Delete_button.TabIndex = 2;
            this.Delete_button.Text = "Delete";
            this.Delete_button.UseVisualStyleBackColor = true;
            this.Delete_button.Click += new System.EventHandler(this.Delete_button_Click);
            // 
            // WarningLabel
            // 
            this.WarningLabel.AutoSize = true;
            this.WarningLabel.Location = new System.Drawing.Point(365, 22);
            this.WarningLabel.Name = "WarningLabel";
            this.WarningLabel.Size = new System.Drawing.Size(0, 20);
            this.WarningLabel.TabIndex = 3;
            // 
            // CategoriesListBox
            // 
            this.CategoriesListBox.FormattingEnabled = true;
            this.CategoriesListBox.ItemHeight = 20;
            this.CategoriesListBox.Items.AddRange(new object[] {
            "Any",
            "Cooking",
            "Studying",
            "Articles",
            "Books",
            "Other"});
            this.CategoriesListBox.Location = new System.Drawing.Point(12, 302);
            this.CategoriesListBox.Name = "CategoriesListBox";
            this.CategoriesListBox.Size = new System.Drawing.Size(150, 104);
            this.CategoriesListBox.TabIndex = 4;
            this.CategoriesListBox.SelectedIndexChanged += new System.EventHandler(this.CategoriesListBox_SelectedIndexChanged);
            // 
            // LogOutButton
            // 
            this.LogOutButton.Location = new System.Drawing.Point(187, 377);
            this.LogOutButton.Name = "LogOutButton";
            this.LogOutButton.Size = new System.Drawing.Size(161, 29);
            this.LogOutButton.TabIndex = 5;
            this.LogOutButton.Text = "Log Out";
            this.LogOutButton.UseVisualStyleBackColor = true;
            this.LogOutButton.Click += new System.EventHandler(this.LogOutButton_Click);
            // 
            // NewNoteButton
            // 
            this.NewNoteButton.Location = new System.Drawing.Point(187, 219);
            this.NewNoteButton.Name = "NewNoteButton";
            this.NewNoteButton.Size = new System.Drawing.Size(161, 29);
            this.NewNoteButton.TabIndex = 6;
            this.NewNoteButton.Text = "New";
            this.NewNoteButton.UseVisualStyleBackColor = true;
            this.NewNoteButton.Click += new System.EventHandler(this.NewNoteButton_Click);
            // 
            // NotesMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.NewNoteButton);
            this.Controls.Add(this.LogOutButton);
            this.Controls.Add(this.CategoriesListBox);
            this.Controls.Add(this.WarningLabel);
            this.Controls.Add(this.Delete_button);
            this.Controls.Add(this.PreviewLabel);
            this.Controls.Add(this.NotesBox);
            this.Name = "NotesMenu";
            this.Text = "NotesMenu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.NotesMenu_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.NotesMenu_FormClosed);
            this.Shown += new System.EventHandler(this.NotesMenu_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox NotesBox;
        private System.Windows.Forms.Label PreviewLabel;
        private System.Windows.Forms.Button Delete_button;
        private System.Windows.Forms.Label WarningLabel;
        private System.Windows.Forms.ListBox CategoriesListBox;
        private System.Windows.Forms.Button LogOutButton;
        private System.Windows.Forms.Button NewNoteButton;
    }
}