﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Linq;
using Keep_Notes.Business_Logic;
namespace Keep_Notes.View
{
    
    public partial class NoteEditor : Form
    {
        int UserId;
        NotesMenu notesMenu;
        INoteLogic logic;
        public NoteEditor(int userId,NotesMenu notes,string mode)
        {
            InitializeComponent();
            UserId = userId;
            notesMenu = notes;
         
            PrivateComboBox.DataSource = new Private[]
            {
                new Private{str="No",val=false },
                new Private{str="Yes",val=true }

            };
            CategoryComboBox.DataSource = new Category[]
            {   new Category{str="--Select--",val="Other" },
                new Category{str="Cooking",val="Cooking" },
                new Category{str="Studying",val="Studying" },
                new Category{str="Articles",val="Articles" },
                new Category{str="Books",val="Books" },
                 new Category{str="Other",val="Other" }

            };
            BackgroundComboBox.DataSource = new Background[]
            {
            new Background{str="--Select--",val="white" },
            new Background{str="Green",val="Green" },
            new Background{str="Blue",val="Blue" },
            new Background{str="White",val="White" }



            };
            PrivateComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            CategoryComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            BackgroundComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            if (mode == "New")
                logic = new NewNote_Logic();
            else
                logic = new EditNote_Logic();

            

            PasswordLabel.Hide();
            PasswordTextBox.Hide();
            
           
        }

        private void NoteEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            addHandlers(this.Controls);
            if (logic.Saved)
                notesMenu.Show();
            else
            {
                DialogResult res = MessageBox.Show(logic.NotSavedMessage, "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (res == DialogResult.Cancel)
                {
                    e.Cancel = true;
                }
                else
                {
                    notesMenu.Show();
                }
            }
        }
        
        private void PrivateComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((bool)PrivateComboBox.SelectedValue == true)
            {
                PasswordLabel.Show();
                PasswordTextBox.Show();
            }
            else
            {
                PasswordLabel.Hide();
                PasswordTextBox.Hide();
            }


        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            if (PasswordTextBox.Text.Length < 5)
            {
                WarningLabel.Text = "Password must be at least 5 characters long";
                return;
            }

            string msg= logic.Save(UserId,TitleTextBox.Text, NoteTextBox.Text, (bool)PrivateComboBox.SelectedValue, CategoryComboBox.SelectedValue.ToString(), BackgroundComboBox.SelectedItem.ToString(), PasswordTextBox.Text);
            if (msg == "Invalid title")
                WarningLabel.Text = "There is already a note with that title";
            else if(msg=="Note Saved")
            {
                WarningLabel.Text = msg;
                
                logic = new EditNote_Logic();
                logic.Saved = true;
            }
            
        }
        private void addHandlers(Control.ControlCollection ctrl)
        {
            foreach (TextBox control in Controls.OfType<TextBox>())
            {
                control.TextChanged += new EventHandler(OnContentChanged);
            }
            foreach (ComboBox control in Controls.OfType<ComboBox>())
            {
                control.SelectedIndexChanged += new EventHandler(OnContentChanged);
            }
            foreach (Control control in Controls)
            {
                if (control.HasChildren)
                    addHandlers(control.Controls);
            }
        }

        protected void OnContentChanged(object sender, EventArgs e)
        {
            logic.Saved = false;
        }

        
    }
    //for combobox
    class Private
    {
        public string str { get; set; }
        public bool val { get; set; }
    }
    class Category
    {
        public string str { get; set; }
        public string val { get; set; }
    }
    class Background
    {
        public string str { get; set; }
        public string val { get; set; }
    }

}
