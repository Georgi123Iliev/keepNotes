﻿using Keep_Notes.Model;
using Keep_Notes.View;
using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Keep_Notes.Business_Logic
{
   public class Logic_NotesMenu_Form
    {
        public static KeepNotesDBContext keepNotesDBContext = new KeepNotesDBContext();
       
        public List<string> UpdateNoteList(int UserId,string keyword="Any")
        {
            
           
            List<Notes> listOfNotes;
            if(keyword=="Any")
            listOfNotes = keepNotesDBContext.Notes.Where(n => n.UserId == UserId).OrderByDescending(n=>n.latest_change).ToList();
            else
                listOfNotes = keepNotesDBContext.Notes.Where(n => n.UserId == UserId && n.Keywords==keyword).OrderByDescending(n => n.latest_change).ToList();


            List<string> titles = new List<string>(listOfNotes.Count);
            foreach (var i in listOfNotes)
                titles.Add(i.Title);
           
            return titles;
        }
        public string DisplayNotePreview(string title,int user_id)
        {
            
                if (keepNotesDBContext.Notes.Where(n => n.Title == title&&n.UserId==user_id).FirstOrDefault().Private)
                    return "***********";
                var note = keepNotesDBContext.Notes.Where(n => n.Title == title && n.UserId == user_id).FirstOrDefault();
                StringBuilder prevText = new StringBuilder();
                foreach (var i in note.Note.Take(20))
                {
                    prevText.Append(i);

                }
                return prevText + (note.Note.Length > 20 ? "..." : "");
            
            
        }
        public System.Drawing.Color DisplayNoteColor(string title,int user_id)
        {
            string color = keepNotesDBContext.Notes.Where(n => n.Title == title && n.UserId == user_id).FirstOrDefault().Color.ToString();
            switch (color)
            {
                
                case "Green": return System.Drawing.Color.LimeGreen;
                case "Blue":   return System.Drawing.Color.Blue;
                default: return System.Drawing.Color.White;
            }
                
           

        }
        public void DeleteNode(string title,int user_id)
        {
            var ToRemove = keepNotesDBContext.Notes.Where(n => n.Title == title && n.UserId == user_id).FirstOrDefault();
            keepNotesDBContext.Notes.Remove(ToRemove);

            keepNotesDBContext.SaveChanges();
           
            
        }
    }
}
