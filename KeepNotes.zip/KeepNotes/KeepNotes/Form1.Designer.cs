﻿namespace KeepNotes
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_username = new System.Windows.Forms.TextBox();
            this.textBox_password = new System.Windows.Forms.TextBox();
            this.label_email = new System.Windows.Forms.Label();
            this.label_password = new System.Windows.Forms.Label();
            this.button_signin = new System.Windows.Forms.Button();
            this.label_title = new System.Windows.Forms.Label();
            this.label_warning = new System.Windows.Forms.Label();
            this.listView_notes = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // textBox_username
            // 
            this.textBox_username.Location = new System.Drawing.Point(195, 130);
            this.textBox_username.Name = "textBox_username";
            this.textBox_username.Size = new System.Drawing.Size(137, 20);
            this.textBox_username.TabIndex = 0;
            this.textBox_username.TextChanged += new System.EventHandler(this.textBox_username_TextChanged);
            // 
            // textBox_password
            // 
            this.textBox_password.Location = new System.Drawing.Point(195, 207);
            this.textBox_password.Name = "textBox_password";
            this.textBox_password.Size = new System.Drawing.Size(137, 20);
            this.textBox_password.TabIndex = 1;
            this.textBox_password.TextChanged += new System.EventHandler(this.textBox_password_TextChanged);
            // 
            // label_email
            // 
            this.label_email.AutoSize = true;
            this.label_email.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_email.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_email.Location = new System.Drawing.Point(99, 131);
            this.label_email.Name = "label_email";
            this.label_email.Size = new System.Drawing.Size(48, 16);
            this.label_email.TabIndex = 2;
            this.label_email.Text = "Email:";
            // 
            // label_password
            // 
            this.label_password.AutoSize = true;
            this.label_password.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_password.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_password.Location = new System.Drawing.Point(89, 207);
            this.label_password.Name = "label_password";
            this.label_password.Size = new System.Drawing.Size(71, 16);
            this.label_password.TabIndex = 3;
            this.label_password.Text = "Password:";
            // 
            // button_signin
            // 
            this.button_signin.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_signin.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button_signin.Location = new System.Drawing.Point(160, 283);
            this.button_signin.Name = "button_signin";
            this.button_signin.Size = new System.Drawing.Size(94, 38);
            this.button_signin.TabIndex = 4;
            this.button_signin.Text = "Sign up";
            this.button_signin.UseVisualStyleBackColor = true;
            this.button_signin.Click += new System.EventHandler(this.button_signin_Click);
            // 
            // label_title
            // 
            this.label_title.AutoSize = true;
            this.label_title.Font = new System.Drawing.Font("Papyrus", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_title.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label_title.Location = new System.Drawing.Point(127, 49);
            this.label_title.Name = "label_title";
            this.label_title.Size = new System.Drawing.Size(177, 42);
            this.label_title.TabIndex = 5;
            this.label_title.Text = "Keep Notes";
            // 
            // label_warning
            // 
            this.label_warning.AutoSize = true;
            this.label_warning.Font = new System.Drawing.Font("Mongolian Baiti", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_warning.ForeColor = System.Drawing.Color.DarkRed;
            this.label_warning.Location = new System.Drawing.Point(122, 97);
            this.label_warning.Name = "label_warning";
            this.label_warning.Size = new System.Drawing.Size(0, 11);
            this.label_warning.TabIndex = 6;
            // 
            // listView_notes
            // 
            this.listView_notes.HideSelection = false;
            this.listView_notes.Location = new System.Drawing.Point(457, 106);
            this.listView_notes.Name = "listView_notes";
            this.listView_notes.Size = new System.Drawing.Size(186, 150);
            this.listView_notes.TabIndex = 7;
            this.listView_notes.UseCompatibleStateImageBehavior = false;
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(757, 379);
            this.Controls.Add(this.listView_notes);
            this.Controls.Add(this.label_warning);
            this.Controls.Add(this.label_title);
            this.Controls.Add(this.button_signin);
            this.Controls.Add(this.label_password);
            this.Controls.Add(this.label_email);
            this.Controls.Add(this.textBox_password);
            this.Controls.Add(this.textBox_username);
            this.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.Name = "Form";
            this.Text = "Keep Notes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_username;
        private System.Windows.Forms.TextBox textBox_password;
        private System.Windows.Forms.Label label_email;
        private System.Windows.Forms.Label label_password;
        private System.Windows.Forms.Button button_signin;
        private System.Windows.Forms.Label label_title;
        private System.Windows.Forms.Label label_warning;
        private System.Windows.Forms.ListView listView_notes;
    }
}

