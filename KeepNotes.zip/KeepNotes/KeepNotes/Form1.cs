﻿using System;
using System.Drawing;
using System.Text.RegularExpressions;

namespace KeepNotes
{
    public partial class Form : System.Windows.Forms.Form
    {
        public Form()
        {
            InitializeComponent();
        }

        private void textBox_username_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_password_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_signin_Click(object sender, EventArgs e)
        {
            string pattern = @"/\w+@\w+\.\w+/g";
            Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
            MatchCollection matches = rgx.Matches(label_email.Text);
            if((matches != null && matches.Count == 1) || (textBox_password.TextLength >= 5))
            {

            }
            else
            {
                label_warning.Text = "Wrong password or username";
            }



            listView_notes.Columns.Add("Column1", 100); // this can also be added 
                                                        // through the design time support 
            listView_notes.Columns.Add("Column2", 100);
            listView_notes.Columns.Add("Column3", 100);
            listView_notes.Columns.Add("Column4", 100);

            GLItem item;

            item = this.glacialList1.Items.Add("Atlanta Braves");
            item.SubItems[1].Text = "8v";
            item.SubItems[2].Text = "Live";
            item.SubItems[2].BackColor = Color.Bisque;
            item.SubItems[3].Text = "MLB.TV";

            item = this.glacialList1.Items.Add("Florida Marlins");
            item.SubItems[1].Text = "";
            item.SubItems[2].Text = "Delayed";
            item.SubItems[2].BackColor = Color.LightCoral;
            item.SubItems[3].Text = "Audio";


            item.SubItems[1].BackColor = Color.Aqua; // set the background 
                                                     // of this particular subitem ONLY
            item.UserObject = myownuserobjecttype; // set a private user object
            item.Selected = true; // set this item to selected state
            item.SubItems[1].Span = 2; // set this sub item to span 2 spaces

            ArrayList selectedItems = mylist.SelectedItems;
            // get list of selected items
        }
    }
}
